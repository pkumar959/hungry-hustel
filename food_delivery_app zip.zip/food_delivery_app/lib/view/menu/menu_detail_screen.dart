// TODO Implement this library.import 'package:flutter/material.dart';

import 'package:flutter/material.dart';

class MenuDetailScreen extends StatelessWidget {
  final String menuName;

  const MenuDetailScreen({super.key, required this.menuName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(menuName),
      ),
      body: Center(
        child: Text(
          "Details for $menuName",
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

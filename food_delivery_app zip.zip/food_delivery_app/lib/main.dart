
import 'dart:io' show HttpOverrides;

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
// import 'package:shared_preferences/shared_preferences.dart';  // Use the correct package
import 'package:food_delivery_app/common/color_extension.dart';
import 'package:food_delivery_app/common/locator.dart';
import 'package:food_delivery_app/common/service_call.dart';
import 'package:food_delivery_app/view/login/welcome_view.dart';
import 'package:food_delivery_app/view/main_tabview/main_tabview.dart';
import 'package:food_delivery_app/view/more/about_us_view.dart';
import 'package:food_delivery_app/view/more/add_card_view.dart';
import 'package:food_delivery_app/view/more/more_view.dart';
import 'package:food_delivery_app/view/on_boarding/startup_view.dart';
import 'package:food_delivery_app/view/profile/profile_view.dart';


import 'common/globs.dart';
import 'common/my_http_overrides.dart';

SharedPreferences? prefs;

class SharedPreferences {
  static getInstance() {}

  void setString(String key, String data) {}

  void setBool(String key, bool data) {}

  void setInt(String key, int data) {}

  void setDouble(String key, double data) {}

  get(String key) {}

  void remove(String key) {}
}

void main() async {
  setUpLocator();
  HttpOverrides.global = MyHttpOverrides();
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();

  if (Globs.udValueBool(Globs.userLogin)) {
    ServiceCall.userPayload = Globs.udValue(Globs.userPayload);
  }

  runApp(const MyApp(defaultHome: StartupView(),));
}

void configLoading() {
  EasyLoading.instance
    ..indicatorType = EasyLoadingIndicatorType.ring
    ..loadingStyle = EasyLoadingStyle.custom
    ..indicatorSize = 45.0
    ..radius = 5.0
    ..progressColor = TColor.primaryText
    ..backgroundColor = TColor.primary
    ..indicatorColor = Colors.yellow
    ..textColor = TColor.primaryText
    ..userInteractions = false
    ..dismissOnTap = false;
}

class MyApp extends StatefulWidget {
  final Widget defaultHome;
  const MyApp({super.key, required this.defaultHome});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: true,
      title: 'Food Delivery',
      
      theme: ThemeData(
        fontFamily: "Metropolis",
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: widget.defaultHome,
      navigatorKey: locator<NavigationService>().navigatorKey,
      onGenerateRoute: (routeSettings) {
        switch (routeSettings.name) {
          case "welcome":
            return MaterialPageRoute(builder: (context) => const WelcomeView());
          case "Home":
            return MaterialPageRoute(builder: (context) => const MainTabView());
          case "About":
            return MaterialPageRoute(builder: (context) => const AboutUsView());
          case "Profile":
            return MaterialPageRoute(builder: (context) => const ProfileView());
          case "Add_Card":
            return MaterialPageRoute(builder: (context) => const AddCardView());
          case "Login":
            return MaterialPageRoute(builder: (context) => const MainTabView());
          case "More_View":
           return MaterialPageRoute(builder: (context) => const MoreView());
          
        }
        return null;
      },
      builder: (context, child) {
        return FlutterEasyLoading(child: child);
      },
    );
  }
}
